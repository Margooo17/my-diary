// 评论管理模块
const Comments = {
    // 创建评论元素
    createCommentElement(comment) {
        const commentElement = document.createElement('div');
        commentElement.className = 'comment';
        commentElement.dataset.id = comment.id;

        const contentElement = document.createElement('p');
        contentElement.className = 'comment-content';
        contentElement.textContent = comment.content;

        const timeElement = document.createElement('span');
        timeElement.className = 'comment-time';
        const date = new Date(comment.createdAt);
        timeElement.textContent = `${date.getFullYear()}年${date.getMonth() + 1}月${date.getDate()}日 ${date.getHours()}:${String(date.getMinutes()).padStart(2, '0')}`;

        const deleteButton = document.createElement('button');
        deleteButton.className = 'delete-comment';
        deleteButton.innerHTML = '&times;';
        deleteButton.title = '删除评论';

        commentElement.appendChild(contentElement);
        commentElement.appendChild(timeElement);
        commentElement.appendChild(deleteButton);

        return commentElement;
    },

    // 创建评论输入区域
    createCommentInput() {
        const inputContainer = document.createElement('div');
        inputContainer.className = 'comment-input-container';

        const textarea = document.createElement('textarea');
        textarea.className = 'comment-input';
        textarea.placeholder = '写下你的想法...';

        const addButton = document.createElement('button');
        addButton.className = 'add-comment';
        addButton.textContent = '添加评论';

        inputContainer.appendChild(textarea);
        inputContainer.appendChild(addButton);

        return inputContainer;
    },

    // 渲染评论列表
    renderComments(diary) {
        const commentsContainer = document.querySelector(`#diary-${diary.id} .comments-container`);
        if (!commentsContainer) return;

        commentsContainer.innerHTML = '';
        
        // 添加评论输入区域
        const inputContainer = this.createCommentInput();
        commentsContainer.appendChild(inputContainer);

        // 添加评论列表
        if (diary.comments && diary.comments.length > 0) {
            const commentsList = document.createElement('div');
            commentsList.className = 'comments-list';
            
            diary.comments.forEach(comment => {
                const commentElement = this.createCommentElement(comment);
                commentsList.appendChild(commentElement);
            });
            
            commentsContainer.appendChild(commentsList);
        }

        // 绑定添加评论事件
        const addButton = commentsContainer.querySelector('.add-comment');
        const textarea = commentsContainer.querySelector('.comment-input');
        
        addButton.addEventListener('click', () => {
            const content = textarea.value.trim();
            if (content) {
                const comment = {
                    content,
                    createdAt: new Date().toISOString()
                };
                
                const newComment = Storage.addComment(diary.id, comment);
                if (newComment) {
                    const commentElement = this.createCommentElement(newComment);
                    const commentsList = commentsContainer.querySelector('.comments-list') || 
                        (() => {
                            const list = document.createElement('div');
                            list.className = 'comments-list';
                            commentsContainer.appendChild(list);
                            return list;
                        })();
                    
                    commentsList.appendChild(commentElement);
                    textarea.value = '';
                }
            }
        });

        // 绑定删除评论事件
        commentsContainer.addEventListener('click', (e) => {
            if (e.target.classList.contains('delete-comment')) {
                const commentElement = e.target.closest('.comment');
                const commentId = commentElement.dataset.id;
                
                if (confirm('确定要删除这条评论吗？')) {
                    if (Storage.deleteComment(diary.id, commentId)) {
                        commentElement.remove();
                        
                        // 如果没有评论了，移除评论列表容器
                        const commentsList = commentsContainer.querySelector('.comments-list');
                        if (commentsList && !commentsList.children.length) {
                            commentsList.remove();
                        }
                    }
                }
            }
        });
    }
}; 