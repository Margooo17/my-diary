// 日记核心功能模块
const Diary = {
    // 初始化
    init() {
        this.bindEvents();
        this.renderDiaries();
        Tags.updateTagsList();
        this.initSearch();
    },

    // 绑定事件
    bindEvents() {
        // 新建日记按钮
        const newDiaryBtn = document.querySelector('.new-diary-btn');
        newDiaryBtn.addEventListener('click', () => this.showDiaryModal());

        // 导入导出按钮
        document.querySelector('.import-btn').addEventListener('click', () => this.handleImport());
        document.querySelector('.export-btn').addEventListener('click', () => Storage.exportData());

        // 初始化标签输入
        Tags.initTagsInput();

        // 使用事件委托处理模态框按钮事件
        document.addEventListener('click', (e) => {
            const modal = document.querySelector('.diary-modal');
            if (!modal || modal.style.display === 'none') return;

            if (e.target.closest('.save-btn')) {
                this.saveAndClose();
            } else if (e.target.closest('.close-btn') || e.target.closest('.cancel-btn')) {
                modal.style.display = 'none';
                modal.querySelector('.diary-content').value = '';
                Tags.setSelectedTags([]);
                delete modal.dataset.diaryId;
            }
        });

        // 添加ESC键关闭功能
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const modal = document.querySelector('.diary-modal');
                if (modal && modal.style.display !== 'none') {
                    modal.style.display = 'none';
                    modal.querySelector('.diary-content').value = '';
                    Tags.setSelectedTags([]);
                    delete modal.dataset.diaryId;
                }
            }
        });
    },

    // 显示写日记弹窗
    showDiaryModal(diary = null) {
        const modal = document.querySelector('.diary-modal');
        const contentInput = modal.querySelector('.diary-content');

        if (diary) {
            contentInput.value = diary.content;
            Tags.setSelectedTags(diary.tags || []);
            modal.dataset.diaryId = diary.id;
        } else {
            contentInput.value = '';
            Tags.setSelectedTags([]);
            delete modal.dataset.diaryId;
        }

        modal.style.display = 'flex';
        contentInput.focus();
    },

    // 分页相关变量
    PAGE_SIZE: 10, // 每页显示的日记数量
    currentPage: 1,

    // 渲染日记列表
    renderDiaries(diaries = null) {
        const diaryList = document.querySelector('.diary-list');
        diaryList.innerHTML = '';

        // 添加统计信息
        const stats = Storage.getStorageStats();
        const statsElement = document.createElement('div');
        statsElement.className = 'diary-stats';
        
        // 生成年份统计HTML
        const yearStatsHtml = Object.entries(stats.yearlyStats)
            .sort(([yearA], [yearB]) => yearB - yearA) // 按年份降序排序
            .map(([year, yearStats]) => `
                <div class="year-stat">
                    <span>${year}年</span>
                    <span class="stat-value ${stats.totalCount > 1500 ? 'warning' : ''}">${yearStats.count}篇</span>
                </div>
            `).join('');

        statsElement.innerHTML = `
            <div class="stats-summary">
                <div class="stat-item">
                    <span class="stat-label">总日记</span>
                    <span class="stat-value ${stats.totalCount > 1500 ? 'warning' : ''}">${stats.totalCount}篇</span>
                    ${stats.totalCount > 1500 ? '<div class="stat-warning">建议导出备份哦~</div>' : ''}
                </div>
            </div>
            <div class="stats-yearly">
                <h3>年度记录</h3>
                ${yearStatsHtml}
            </div>
        `;
        
        diaryList.appendChild(statsElement);

        // 获取日记数据
        const allDiaries = diaries || Storage.getAllDiaries();
        
        // 计算总页数
        const totalPages = Math.ceil(allDiaries.length / this.PAGE_SIZE);
        
        // 获取当前页的日记
        const startIndex = (this.currentPage - 1) * this.PAGE_SIZE;
        const endIndex = startIndex + this.PAGE_SIZE;
        const currentDiaries = allDiaries.slice(startIndex, endIndex);
        
        // 渲染日记列表
        currentDiaries.forEach(diary => {
            const diaryElement = document.createElement('article');
            diaryElement.id = `diary-${diary.id}`;
            diaryElement.className = 'diary-card';
            
            // 处理标签显示
            let tagsHtml = '';
            if (Array.isArray(diary.tags)) {
                tagsHtml = diary.tags.map(tag => `<span class="tag">${tag}</span>`).join('');
            } else if (diary.tags) {
                // 兼容旧数据
                tagsHtml = diary.tags.split(',')
                    .map(tag => tag.trim())
                    .filter(tag => tag.length > 0)
                    .map(tag => `<span class="tag">${tag}</span>`)
                    .join('');
            }
            
            diaryElement.innerHTML = `
                <div class="date">${new Date(diary.createdAt).toLocaleString()}</div>
                <div class="content">${diary.content}</div>
                <div class="tags">
                    ${tagsHtml}
                </div>
                <div class="comments-container"></div>
            `;

            // 添加编辑和删除按钮
            const actions = document.createElement('div');
            actions.className = 'diary-actions';
            actions.innerHTML = `
                <button class="edit-btn">编辑</button>
                <button class="delete-btn">删除</button>
            `;

            actions.querySelector('.edit-btn').onclick = () => this.showDiaryModal(diary);
            actions.querySelector('.delete-btn').onclick = () => {
                if (confirm('确定要删除这篇日记吗？')) {
                    Storage.deleteDiary(diary.id);
                    this.renderDiaries();
                    Tags.updateTagsList();
                }
            };

            diaryElement.appendChild(actions);
            diaryList.appendChild(diaryElement);

            // 渲染评论
            const commentsContainer = diaryElement.querySelector('.comments-container');
            if (commentsContainer) {
                Comments.renderComments(diary);
            }
        });
        
        // 添加分页控件
        const paginationContainer = document.createElement('div');
        paginationContainer.className = 'pagination';
        
        // 上一页按钮
        const prevBtn = document.createElement('button');
        prevBtn.className = 'pagination-btn prev-btn';
        prevBtn.innerHTML = `
            <svg viewBox="0 0 24 24" width="16" height="16">
                <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z" fill="currentColor"/>
            </svg>
        `;
        prevBtn.disabled = this.currentPage === 1;
        prevBtn.addEventListener('click', () => {
            if (this.currentPage > 1) {
                this.currentPage--;
                this.renderDiaries();
            }
        });
        
        // 页码信息
        const pageInfo = document.createElement('span');
        pageInfo.className = 'page-info';
        pageInfo.textContent = `${this.currentPage} / ${totalPages}`;
        
        // 下一页按钮
        const nextBtn = document.createElement('button');
        nextBtn.className = 'pagination-btn next-btn';
        nextBtn.innerHTML = `
            <svg viewBox="0 0 24 24" width="16" height="16">
                <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z" fill="currentColor"/>
            </svg>
        `;
        nextBtn.disabled = this.currentPage === totalPages;
        nextBtn.addEventListener('click', () => {
            if (this.currentPage < totalPages) {
                this.currentPage++;
                this.renderDiaries();
            }
        });
        
        paginationContainer.appendChild(prevBtn);
        paginationContainer.appendChild(pageInfo);
        paginationContainer.appendChild(nextBtn);
        diaryList.appendChild(paginationContainer);
    },

    // 处理数据导入
    handleImport() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        
        input.onchange = (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (event) => {
                    const jsonData = event.target.result;
                    if (Storage.importData(jsonData)) {
                        this.renderDiaries();
                        Tags.updateTagsList();
                        alert('数据导入成功！');
                    } else {
                        alert('数据导入失败，请检查文件格式是否正确。');
                    }
                };
                reader.readAsText(file);
            }
        };

        input.click();
    },

    saveAndClose() {
        const modal = document.querySelector('.diary-modal');
        if (!modal) {
            console.log('Modal not found');
            return;
        }

        const contentInput = modal.querySelector('.diary-content');
        const content = contentInput.value.trim();
        const tags = Tags.getSelectedTags();

        if (content) {
            const diaryId = modal.dataset.diaryId;
            if (diaryId) {
                // 更新现有日记
                Storage.updateDiary(diaryId, { content, tags });
            } else {
                // 创建新日记
                Storage.addDiary({ content, tags });
                // 显示写作达成动画
                const animation = document.createElement('div');
                animation.className = 'writing-achievement';
                const encouragements = Storage.getEncouragements();
                const randomEncouragement = encouragements[Math.floor(Math.random() * encouragements.length)];
                animation.innerHTML = `
                    <div class="achievement-content">
                        <svg class="achievement-icon" viewBox="0 0 24 24" width="32" height="32">
                            <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" 
                                  fill="currentColor"/>
                        </svg>
                        <span class="achievement-text">${randomEncouragement}</span>
                    </div>
                `;
                document.body.appendChild(animation);
                animation.addEventListener('animationend', () => {
                    animation.remove();
                });
            }
            this.renderDiaries();
            Tags.updateTagsList();
        }
        
        // 关闭模态框
        modal.style.display = 'none';
        modal.querySelector('.diary-content').value = '';
        Tags.setSelectedTags([]);
        delete modal.dataset.diaryId;
    },

    // 初始化搜索功能
    initSearch() {
        const searchInput = document.querySelector('.search-input');
        const searchBtn = document.querySelector('.search-btn');
        const dateCheckbox = document.querySelector('.search-date');
        const dateRange = document.querySelector('.date-range');
        const contentCheckbox = document.querySelector('.search-content');
        const commentsCheckbox = document.querySelector('.search-comments');

        if (!searchInput || !searchBtn) {
            console.warn('搜索相关元素未找到');
            return;
        }

        // 切换日期范围选择器的显示
        dateCheckbox.addEventListener('change', (e) => {
            dateRange.style.display = e.target.checked ? 'flex' : 'none';
            if (e.target.checked) {
                // 设置默认日期范围（最近一个月）
                const end = new Date();
                const start = new Date();
                start.setMonth(start.getMonth() - 1);
                
                document.querySelector('.date-start').value = start.toISOString().split('T')[0];
                document.querySelector('.date-end').value = end.toISOString().split('T')[0];
            }
        });

        // 防抖函数
        const debounce = (func, wait) => {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        };

        // 检查日期是否在范围内
        const isDateInRange = (dateStr) => {
            if (!dateCheckbox.checked) return true;
            
            const startDate = new Date(document.querySelector('.date-start').value);
            const endDate = new Date(document.querySelector('.date-end').value);
            endDate.setHours(23, 59, 59); // 设置为当天结束
            
            const date = new Date(dateStr);
            return date >= startDate && date <= endDate;
        };

        // 搜索函数
        const searchDiaries = (searchText) => {
            let filteredDiaries = [];
            
            // 如果启用内容搜索或评论搜索，使用索引搜索
            if ((contentCheckbox.checked || commentsCheckbox.checked) && searchText) {
                filteredDiaries = Storage.searchByIndex(searchText);
            } else {
                // 否则使用常规筛选
                const diaries = Storage.getAllDiaries();
                filteredDiaries = diaries.filter(diary => {
                    // 如果没有搜索文本且不需要日期筛选，显示所有日记
                    if (!searchText && !dateCheckbox.checked) return true;

                    // 检查日期范围
                    if (dateCheckbox.checked && !isDateInRange(diary.createdAt)) {
                        return false;
                    }

                    if (!searchText) return true;
                    
                    return false; // 如果需要搜索文本但没有选择搜索目标，则不显示
                });
            }
            
            // 应用日期过滤
            if (dateCheckbox.checked) {
                filteredDiaries = filteredDiaries.filter(diary => isDateInRange(diary.createdAt));
            }

            // 渲染搜索结果
            this.renderDiaries(filteredDiaries);

            // 高亮匹配文本
            if (searchText) {
                const diaryElements = document.querySelectorAll('.diary-card');
                const searchRegex = new RegExp(searchText, 'gi');
                
                diaryElements.forEach(element => {
                    if (contentCheckbox.checked) {
                        const content = element.querySelector('.content');
                        if (content) {
                            content.innerHTML = content.textContent.replace(
                                searchRegex,
                                match => `<mark class="highlight">${match}</mark>`
                            );
                        }
                    }

                    if (commentsCheckbox.checked) {
                        const comments = element.querySelectorAll('.comment-content');
                        comments.forEach(comment => {
                            comment.innerHTML = comment.textContent.replace(
                                searchRegex,
                                match => `<mark class="highlight">${match}</mark>`
                            );
                        });
                    }
                });
            }
        };

        // 添加搜索事件监听器
        const debouncedSearch = debounce((searchText) => searchDiaries(searchText), 300);

        // 监听搜索框输入
        searchInput.addEventListener('input', (e) => {
            debouncedSearch(e.target.value.trim());
        });

        // 监听搜索按钮点击
        searchBtn.addEventListener('click', () => {
            searchDiaries(searchInput.value.trim());
        });

        // 监听回车键
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                searchDiaries(searchInput.value.trim());
            }
        });

        // 监听搜索选项变化
        [contentCheckbox, dateCheckbox, commentsCheckbox].forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                searchDiaries(searchInput.value.trim());
            });
        });

        // 监听日期范围变化
        document.querySelector('.date-start').addEventListener('change', () => {
            if (dateCheckbox.checked) searchDiaries(searchInput.value.trim());
        });
        document.querySelector('.date-end').addEventListener('change', () => {
            if (dateCheckbox.checked) searchDiaries(searchInput.value.trim());
        });
    }
};

// 初始化应用
document.addEventListener('DOMContentLoaded', () => {
    Diary.init();
}); 