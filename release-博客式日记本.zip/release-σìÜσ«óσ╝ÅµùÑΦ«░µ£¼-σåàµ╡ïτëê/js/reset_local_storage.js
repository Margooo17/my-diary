// 重置脚本 - 仅首次运行时执行
(function() {
    // 检查是否已运行过初始化
    if (!localStorage.getItem('app_initialized')) {
        console.log('首次运行初始化...');
        
        // 清除所有localStorage数据
        localStorage.clear();
        
        // 设置默认标题
        localStorage.setItem('diaryTitle', '博客式日记本');
        
        // 设置默认鼓励语
        localStorage.setItem('diary_encouragements', JSON.stringify(['太棒啦🥳', '今天也很棒呢！', '坚持写日记的你最棒！']));
        
        // 设置默认主题
        localStorage.setItem('theme', 'light');
        
        // 标记为已初始化
        localStorage.setItem('app_initialized', 'true');
        
        console.log('初始化完成！');
    }
})();
