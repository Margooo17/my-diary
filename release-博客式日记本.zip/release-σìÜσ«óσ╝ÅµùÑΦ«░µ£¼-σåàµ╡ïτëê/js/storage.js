// 数据存储管理模块
const Storage = {
    // 存储限制常量
    LIMITS: {
        WARNING_COUNT: 1500,  // 警告阈值
        CRITICAL_COUNT: 2000, // 临界阈值
    },

    // 搜索索引结构
    _searchIndex: null,

    // 构建搜索索引
    buildSearchIndex() {
        const diaries = this.getAllDiaries();
        const index = {};
        
        // 为每个日记和评论建立索引
        diaries.forEach(diary => {
            // 为内容分词并索引
            const words = this._tokenize(diary.content);
            words.forEach(word => {
                if (!index[word]) index[word] = [];
                if (!index[word].includes(diary.id)) {
                    index[word].push(diary.id);
                }
            });
            
            // 为评论建立索引
            if (Array.isArray(diary.comments)) {
                diary.comments.forEach(comment => {
                    const commentWords = this._tokenize(comment.content);
                    commentWords.forEach(word => {
                        if (!index[word]) index[word] = [];
                        if (!index[word].includes(diary.id)) {
                            index[word].push(diary.id);
                        }
                    });
                });
            }
            
            // 为标签建立索引
            if (Array.isArray(diary.tags)) {
                diary.tags.forEach(tag => {
                    const tagWords = this._tokenize(tag);
                    tagWords.forEach(word => {
                        if (!index[word]) index[word] = [];
                        if (!index[word].includes(diary.id)) {
                            index[word].push(diary.id);
                        }
                    });
                });
            }
        });
        
        this._searchIndex = index;
        return index;
    },
    
    // 简单分词函数
    _tokenize(text) {
        if (!text) return [];
        return text.toLowerCase()
            .replace(/[^\w\s\u4e00-\u9fa5]/g, '') // 移除标点符号，保留中文字符
            .split(/\s+/)
            .filter(word => word.length > 0);
    },
    
    // 使用索引进行搜索
    searchByIndex(query) {
        if (!query || query.trim() === '') return this.getAllDiaries();
        
        // 如果索引不存在，先构建索引
        if (!this._searchIndex) {
            this.buildSearchIndex();
        }
        
        // 分词搜索
        const searchTerms = this._tokenize(query);
        if (searchTerms.length === 0) return this.getAllDiaries();
        
        // 查找匹配的日记ID
        const matchedIds = new Set();
        let isFirstTerm = true;
        
        searchTerms.forEach(term => {
            const matchingIds = this._searchIndex[term] || [];
            
            if (isFirstTerm) {
                // 对于第一个词，直接添加所有匹配ID
                matchingIds.forEach(id => matchedIds.add(id));
                isFirstTerm = false;
            } else {
                // 对于后续词，只保留与前面词共同匹配的ID
                const currentMatches = new Set();
                matchingIds.forEach(id => {
                    if (matchedIds.has(id)) {
                        currentMatches.add(id);
                    }
                });
                
                // 更新匹配结果
                matchedIds.clear();
                currentMatches.forEach(id => matchedIds.add(id));
            }
        });
        
        // 获取所有日记
        const diaries = this.getAllDiaries();
        
        // 如果没有匹配结果，返回空数组
        if (matchedIds.size === 0) return [];
        
        // 返回匹配的日记
        return diaries.filter(diary => matchedIds.has(diary.id));
    },

    // 在各种数据变更后更新索引
    updateSearchIndex() {
        this._searchIndex = null; // 清除旧索引
        this.buildSearchIndex(); // 重建索引
    },

    // 获取所有日记
    getAllDiaries() {
        const diaries = localStorage.getItem('diaries');
        return diaries ? JSON.parse(diaries) : [];
    },

    // 获取存储统计信息
    getStorageStats() {
        const diaries = this.getAllDiaries();
        const totalCount = diaries.length;
        
        // 按年份分组统计
        const yearlyStats = diaries.reduce((stats, diary) => {
            const year = new Date(diary.createdAt).getFullYear();
            if (!stats[year]) {
                stats[year] = {
                    count: 0,
                    totalBytes: 0
                };
            }
            stats[year].count++;
            // 估算单篇日记大小
            const diarySize = JSON.stringify(diary).length;
            stats[year].totalBytes += diarySize;
            return stats;
        }, {});

        // 计算总存储大小
        const totalBytes = Object.values(yearlyStats).reduce(
            (sum, stat) => sum + stat.totalBytes, 0
        );

        // 检查是否需要备份提醒
        const needsBackup = totalCount >= this.LIMITS.WARNING_COUNT;
        const isNearLimit = totalCount >= this.LIMITS.CRITICAL_COUNT;

        return {
            totalCount,
            totalBytes,
            yearlyStats,
            needsBackup,
            isNearLimit,
            remainingCount: this.LIMITS.CRITICAL_COUNT - totalCount
        };
    },

    // 保存所有日记
    saveAllDiaries(diaries) {
        localStorage.setItem('diaries', JSON.stringify(diaries));
        
        // 检查并显示存储警告
        const stats = this.getStorageStats();
        if (stats.needsBackup) {
            this.showStorageWarning(stats);
        }
    },

    // 显示存储警告
    showStorageWarning(stats) {
        if (stats.isNearLimit) {
            alert(`⚠️ 警告：您的日记数量已达到${stats.totalCount}篇，即将达到存储上限！\n\n` +
                  `建议立即备份数据并清理旧日记。\n` +
                  `您可以按年份导出数据，然后删除较早的日记。`);
        } else if (stats.needsBackup) {
            alert(`提示：您的日记数量已达到${stats.totalCount}篇。\n\n` +
                  `建议及时备份数据，以防意外丢失。\n` +
                  `您还可以存储约${stats.remainingCount}篇日记。`);
        }
    },

    // 添加新日记
    addDiary(diary) {
        const result = this._addDiary(diary);
        this.updateSearchIndex();
        return result;
    },

    // 保存原始方法
    _addDiary(diary) {
        const diaries = this.getAllDiaries();
        const newDiary = {
            id: Date.now().toString(),
            content: diary.content,
            tags: diary.tags || [],
            comments: [], // 初始化评论数组
            createdAt: new Date().toISOString()
        };
        diaries.unshift(newDiary);
        this.saveAllDiaries(diaries);
        return newDiary;
    },

    // 更新日记
    updateDiary(id, updatedDiary) {
        const result = this._updateDiary(id, updatedDiary);
        this.updateSearchIndex();
        return result;
    },

    _updateDiary(id, updatedDiary) {
        const diaries = this.getAllDiaries();
        const index = diaries.findIndex(diary => diary.id === id);
        if (index !== -1) {
            diaries[index] = { ...diaries[index], ...updatedDiary };
            this.saveAllDiaries(diaries);
            return diaries[index];
        }
        return null;
    },

    // 删除日记
    deleteDiary(id) {
        this._deleteDiary(id);
        this.updateSearchIndex();
    },

    _deleteDiary(id) {
        const diaries = this.getAllDiaries();
        const filteredDiaries = diaries.filter(diary => diary.id !== id);
        this.saveAllDiaries(filteredDiaries);
    },

    // 按年份获取日记
    getDiariesByYear(year) {
        const diaries = this.getAllDiaries();
        return diaries.filter(diary => 
            new Date(diary.createdAt).getFullYear() === year
        );
    },

    // 按年份导出数据
    exportDataByYear(year) {
        const diaries = this.getDiariesByYear(year);
        const blob = new Blob([JSON.stringify(diaries, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `diary-backup-${year}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    },

    // 导出所有数据
    exportData() {
        const stats = this.getStorageStats();
        const years = Object.keys(stats.yearlyStats).sort();
        
        if (years.length > 1) {
            const exportYear = confirm(
                `您目前共有${stats.totalCount}篇日记，跨越${years.length}个年份（${years[0]}~${years[years.length-1]}）。\n\n` +
                `是否要按年份分别导出？\n` +
                `- 点击"确定"：按年份分别导出\n` +
                `- 点击"取消"：导出全部数据`
            );
            
            if (exportYear) {
                years.forEach(year => this.exportDataByYear(parseInt(year)));
                return;
            }
        }
        
        // 导出全部数据
        const data = this.getAllDiaries();
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `diary-backup-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    },

    // 导入数据
    importData(jsonData) {
        try {
            const data = JSON.parse(jsonData);
            if (Array.isArray(data)) {
                // 检查导入后是否会超出限制
                const currentCount = this.getAllDiaries().length;
                const importCount = data.length;
                const totalCount = currentCount + importCount;
                
                if (totalCount > this.LIMITS.CRITICAL_COUNT) {
                    alert(`警告：导入的${importCount}篇日记加上现有的${currentCount}篇日记，` +
                          `将超出${this.LIMITS.CRITICAL_COUNT}篇的存储限制。\n\n` +
                          `建议先清理一些旧日记，或者分批导入。`);
                    return false;
                }
                
                this.saveAllDiaries([...data, ...this.getAllDiaries()]);
                return true;
            }
            return false;
        } catch (error) {
            console.error('导入数据失败:', error);
            return false;
        }
    },

    // 添加评论
    addComment(diaryId, comment) {
        const diaries = this.getAllDiaries();
        const diary = diaries.find(d => d.id === diaryId);
        if (diary) {
            if (!Array.isArray(diary.comments)) {
                diary.comments = [];
            }
            const newComment = {
                id: Date.now().toString(),
                content: comment.content,
                createdAt: comment.createdAt
            };
            diary.comments.push(newComment);
            this.saveAllDiaries(diaries);
            return newComment;
        }
        return null;
    },

    // 删除评论
    deleteComment(diaryId, commentId) {
        const diaries = this.getAllDiaries();
        const diary = diaries.find(d => d.id === diaryId);
        if (diary && Array.isArray(diary.comments)) {
            diary.comments = diary.comments.filter(c => c.id !== commentId);
            this.saveAllDiaries(diaries);
            return true;
        }
        return false;
    },

    // 获取鼓励语列表
    getEncouragements() {
        const encouragements = localStorage.getItem('diary_encouragements');
        return encouragements ? JSON.parse(encouragements) : ['太棒啦🥳'];
    },

    // 保存鼓励语列表
    saveEncouragements(encouragements) {
        if (!Array.isArray(encouragements) || encouragements.length > 3) {
            throw new Error('鼓励语必须是数组，且不能超过3条');
        }
        localStorage.setItem('diary_encouragements', JSON.stringify(encouragements));
    }
}; 